#include <iostream>
#include "graph.h"
using namespace std;

int main()
{
    graph G;
    initGraph_103022330008(G);

    buildGraph_103022330008(G);

    showVertex(G);

    return 0;
}
